// fake_runner contains test fixtures.
package fake_runner
